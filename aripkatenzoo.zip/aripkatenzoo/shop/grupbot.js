// jangan di ubah jika tidak punya group bot, takutnya eror
const gcbotwa = () =>{
	return`Join Aja Semua Fitur Bot Bisa Digunakan !

1. *Alphabot Support*
_https://chat.whatsapp.com/EU890BcXjyBDkNaUT5WmYV_
2. *Alphabot Support 2*
_https://chat.whatsapp.com/E8NExJwIbhBJYzssfqJNsE_
3. *Alphabot Support 3*
_https://chat.whatsapp.com/KCSqHTky1apG7ApePsfiPy_
4. *Alphabot Support 4* 
_https://chat.whatsapp.com/KwmvHr7VMFj7r5ry9xmMsU_

Jika ada link yang ke reset, silahkan hubungi
owner untuk meminta link yang baru
`
}
exports.gcbotwa = gcbotwa